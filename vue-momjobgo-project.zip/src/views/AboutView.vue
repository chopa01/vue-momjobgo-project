<template>
  <div class="about">
    <h1>todolist 기능</h1>
    <div>
      1. 작업할 일을 등록하세요 => 글 등록 가능 <p/>
      2.체크박스 클릭시 <br/>
      1) Complete로 인정 <br/>
      2) 휴지통 아이콘 클릭 시 삭제<p/>
      3. 소트 기능 및 건 수 보여주기<br/>
      1) All - 전체<br/>
      2) Active - 작업할 내용<br/>
      3) Complete -  완료된 내용 <br/>
      4) Clear completed - 체크박스 일괄 삭제 <br/>
    </div>
  </div>
</template>

<script>
export default {

}
</script>